package com.example.slaroub.qrhunter;

import android.Manifest;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.BitmapDrawable;
import android.media.MediaPlayer;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.RequiresApi;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.InputType;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.Random;

import static android.Manifest.permission.RECORD_AUDIO;
import static android.Manifest.permission.WRITE_EXTERNAL_STORAGE;
import static android.provider.MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE;
import static android.provider.MediaStore.Files.FileColumns.MEDIA_TYPE_VIDEO;

public class AjouterIndice extends AppCompatActivity {

    private static final int ACTIVITY_START_CAMERA_APP = 0;
    private ImageView mPhotoCapturedImageView;
    private String mImageFileLocation = ".";
    private String chemin ="";
    String AudioSavePathInDevice = null;
    public static final int RequestPermissionCode = 1;
    String RecupIndiceTexte = null;
    private ImageView prPhoto, mic, micR, micT, texte, texteT, valider;
    private boolean imageInseree = false;
    private boolean texteInseree = false;
    private boolean audioInseree = false;
    MediaRecorder myAudioRecorder;
    MediaPlayer mediaPlayer;
    DBAdapter db;
    public int numEtape;
    ArrayList<Clues> indicesRecup;


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ajouter_indice);
        if(getIntent().getExtras()!=null) {
            Bundle p = getIntent().getExtras();
            numEtape = p.getInt("etape");
            if(p.get("liste")!=null){
                indicesRecup = (ArrayList<Clues>) p.get("liste");
            }
        }


        prPhoto = (ImageView) findViewById(R.id.appPhoto);



        micR = (ImageView) findViewById(R.id.microR);
        mic = (ImageView) findViewById(R.id.micro);
        micT = (ImageView) findViewById(R.id.microT);
        texte = (ImageView) findViewById(R.id.indiceText);
        texteT = (ImageView) findViewById(R.id.tickedText);
        valider = (ImageView) findViewById(R.id.validerIndice);
        db = new DBAdapter(this,"",null,1);




        texte.setOnClickListener(new View.OnClickListener() {
                                     @Override
                                     public void onClick(View view) {
                                         AlertDialog.Builder dialog = new AlertDialog.Builder((AjouterIndice.this));


                                         dialog.setTitle("Entrez un indice textuel");
                                         final EditText input = new EditText(AjouterIndice.this);


                                         input.setInputType(InputType.TYPE_CLASS_TEXT);
                                         input.setSingleLine(false);
                                         input.setLines(4);
                                         input.setMaxLines(5);
                                         input.setGravity(Gravity.LEFT | Gravity.TOP);
                                         input.setHorizontalScrollBarEnabled(false);
                                         dialog.setView(input);


                                         dialog.setPositiveButton("Valider l'indice", new DialogInterface.OnClickListener() {
                                             @Override
                                             public void onClick(DialogInterface dialog, int which) {
                                                 texte.setVisibility(View.INVISIBLE);
                                                 texteT.setVisibility(View.VISIBLE);
                                                 RecupIndiceTexte = input.getText().toString();
                                                 texteInseree=true;
                                                 dialog.dismiss();
                                             }
                                         });
                                         dialog.setNegativeButton("Annuler", new DialogInterface.OnClickListener() {
                                             @Override
                                             public void onClick(DialogInterface dialog, int which) {
                                                 dialog.dismiss();
                                             }
                                         });
                                         dialog.show();
                                     }

                                 });

        texteT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder dialog = new AlertDialog.Builder((AjouterIndice.this));


                dialog.setTitle("Que voulez vous faire ?");
                final EditText input = new EditText(AjouterIndice.this);

                input.setText(RecupIndiceTexte);
                input.setInputType(InputType.TYPE_CLASS_TEXT);
                input.setSingleLine(false);
                input.setLines(4);
                input.setMaxLines(5);
                input.setGravity(Gravity.LEFT | Gravity.TOP);
                input.setHorizontalScrollBarEnabled(false);
                dialog.setView(input);


                dialog.setPositiveButton("Modifier l'indice", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        RecupIndiceTexte = input.getText().toString();
                        texte.setVisibility(View.INVISIBLE);
                        texteT.setVisibility(View.VISIBLE);
                        dialog.dismiss();
                    }
                });
                dialog.setNegativeButton("Annuler", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                dialog.show();
            }

        });




            mic.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    try {
                        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
                        String soundFileName = "SON_" + timeStamp + "_";
                        AudioSavePathInDevice =
                                Environment.getExternalStorageDirectory().getAbsolutePath() + "/" +
                                        soundFileName + ".3gp";
                        if(checkPermission()) {

                            recordMic(view);
                        }else {
                            requestPermission();
                        }
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            });

        prPhoto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // capture picture
                takePhoto(v);
            }
        });

        micT.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AlertDialog.Builder dialog = new AlertDialog.Builder((AjouterIndice.this));


                dialog.setTitle("Indice sonore");
                dialog.setMessage("Que voulez vous faire ?");



                dialog.setPositiveButton("Ecouter", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        mediaPlayer = new MediaPlayer();
                        try {
                            mediaPlayer.setDataSource(AudioSavePathInDevice);
                            mediaPlayer.prepare();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        mediaPlayer.start();
                        dialog.dismiss();
                    }
                });

                dialog.setNegativeButton("Relancer l'enregistrement", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        micT.setVisibility(View.INVISIBLE);
                        micR.setVisibility(View.VISIBLE);
                        final Animation anim = new AlphaAnimation(0.0f, 1.0f);
                        anim.setDuration(800);
                        anim.setStartOffset(20);
                        anim.setRepeatMode(Animation.REVERSE);
                        anim.setRepeatCount(Animation.INFINITE);
                        micR.startAnimation(anim);

                        myAudioRecorder = new MediaRecorder();
                        myAudioRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
                        myAudioRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
                        myAudioRecorder.setAudioEncoder(MediaRecorder.OutputFormat.AMR_NB);
                        myAudioRecorder.setOutputFile(AudioSavePathInDevice);
                        try {
                            myAudioRecorder.prepare();
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        myAudioRecorder.start();
                        dialog.dismiss();
                    }
                });
                dialog.show();




            }
        });

        valider.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(imageInseree || audioInseree || texteInseree) {
                   // byte[] save = imageViewToByte(prPhoto);
                   // db.insertIndices(133,522,1,"Ceci est un indice", save);

                    // db.dropTable();
                    // db.insertIndices(155,1,"Ceci est un teste", mImageFileLocation, AudioSavePathInDevice);
                  /*  nosIndices.get(numEtape).setQRID_(1);
                    nosIndices.get(numEtape).setIDC_(1);
                    nosIndices.get(numEtape).setNUMETAPE_(1);
                    nosIndices.get(numEtape).setINDTEXTE_(RecupIndiceTexte);
                    nosIndices.get(numEtape).setINDPHOTO_(mImageFileLocation);
                    nosIndices.get(numEtape).setINDAUDIO_(AudioSavePathInDevice);*/
                    Intent intent = new Intent(AjouterIndice.this, CreerChasse.class);
                    numEtape =numEtape+1;
                    intent.putExtra("cheminTexte", RecupIndiceTexte);
                    intent.putExtra("cheminPhoto", mImageFileLocation);
                    intent.putExtra("cheminAudio", AudioSavePathInDevice);
                    intent.putExtra("numetape", numEtape);
                    if(indicesRecup!=null || indicesRecup.size()>0){
                        intent.putExtra("liste", indicesRecup);
                    }
                    startActivity(intent);
                }
            }
        });
        }

    @RequiresApi(api = Build.VERSION_CODES.M)
    public void takePhoto(View view) {
        Intent callCameraApplicationIntent = new Intent();
        final int MY_CAMERA_REQUEST_CODE = 100;
        if (checkSelfPermission(Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.CAMERA},
                    MY_CAMERA_REQUEST_CODE);
        }

        callCameraApplicationIntent.setAction(MediaStore.ACTION_IMAGE_CAPTURE);

        File photoFile = null;
        try {
            photoFile = createImageFile();

        } catch (IOException e) {
            e.printStackTrace();
        }
        String authorities = getApplicationContext().getPackageName() +".fileprovider";
        Uri imageUri = FileProvider.getUriForFile(this, authorities, photoFile);
        // callCameraApplicationIntent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(photoFile));
        callCameraApplicationIntent.putExtra(MediaStore.EXTRA_OUTPUT, imageUri);
        startActivityForResult(callCameraApplicationIntent, ACTIVITY_START_CAMERA_APP);
    }

    public void recordMic(View view) throws IOException {
        mic.setVisibility(View.INVISIBLE);
        micR.setVisibility(View.VISIBLE);
        final Animation anim = new AlphaAnimation(0.0f, 1.0f);
        anim.setDuration(800);
        anim.setStartOffset(20);
        anim.setRepeatMode(Animation.REVERSE);
        anim.setRepeatCount(Animation.INFINITE);
        micR.startAnimation(anim);

        myAudioRecorder = new MediaRecorder();
        myAudioRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
        myAudioRecorder.setOutputFormat(MediaRecorder.OutputFormat.THREE_GPP);
        myAudioRecorder.setAudioEncoder(MediaRecorder.OutputFormat.AMR_NB);
        myAudioRecorder.setOutputFile(AudioSavePathInDevice);
        myAudioRecorder.prepare();
        myAudioRecorder.start();
        audioInseree=true;
        micR.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                anim.cancel();
                micT.setVisibility(View.VISIBLE);
                micR.setVisibility(View.INVISIBLE);
                myAudioRecorder.stop();
            }
        });
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == ACTIVITY_START_CAMERA_APP && resultCode == RESULT_OK) {
            Toast.makeText(this, "Picture taken successfully", Toast.LENGTH_SHORT).show();
           // Bundle extras = data.getExtras();
            //Bitmap photoCapturedBitmap = (Bitmap) extras.get("data");
            //mPhotoCapturedImageView.setImageBitmap(photoCapturedBitmap);

            Bitmap photoCapturedBitmap = BitmapFactory.decodeFile(mImageFileLocation);
          //  Toast.makeText(AjouterIndice.this,mImageFileLocation, Toast.LENGTH_SHORT).show();
            int w, h;
           // h = prPhoto.getHeight();
           // w = prPhoto.getWidth();

            imageInseree = true;
            prPhoto.setImageBitmap(photoCapturedBitmap);
            //photoCapturedBitmap.setHeight(h);
            //photoCapturedBitmap.setWidth(w);
            //setReducedImageSize();


        }
    }

    File createImageFile() throws IOException {

        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String imageFileName = "IMAGE_" + timeStamp + "_";
        File storageDirectory = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);

        File image = File.createTempFile(imageFileName, ".jpg", storageDirectory);
        chemin = image.getAbsolutePath();
        mImageFileLocation = image.getAbsolutePath();

        return image;

    }
/*
    void setReducedImageSize() {
        int targetImageViewWidth = mPhotoCapturedImageView.getWidth();
        int targetImageViewHeight = mPhotoCapturedImageView.getHeight();

        BitmapFactory.Options bmOptions = new BitmapFactory.Options();
        bmOptions.inJustDecodeBounds = true;
        BitmapFactory.decodeFile(mImageFileLocation, bmOptions);
        int cameraImageWidth = bmOptions.outWidth;
        int cameraImageHeight = bmOptions.outHeight;

        int scaleFactor = Math.min(cameraImageWidth / targetImageViewWidth, cameraImageHeight / targetImageViewHeight);
        bmOptions.inSampleSize = scaleFactor;
        bmOptions.inJustDecodeBounds = false;

        Bitmap photoReducedSizeBitmp = BitmapFactory.decodeFile(mImageFileLocation, bmOptions);
        mPhotoCapturedImageView.setImageBitmap(photoReducedSizeBitmp);
    }*/


    private void requestPermission() {
        ActivityCompat.requestPermissions(AjouterIndice.this, new
                String[]{WRITE_EXTERNAL_STORAGE, RECORD_AUDIO}, RequestPermissionCode);
    }

    public boolean checkPermission() {
        int result = ContextCompat.checkSelfPermission(getApplicationContext(),
                WRITE_EXTERNAL_STORAGE);
        int result1 = ContextCompat.checkSelfPermission(getApplicationContext(),
                RECORD_AUDIO);
        return result == PackageManager.PERMISSION_GRANTED &&
                result1 == PackageManager.PERMISSION_GRANTED;
    }


    /*

    private byte[] imageViewToByte(ImageView image){
        Bitmap bitmAConv = ((BitmapDrawable) image.getDrawable()).getBitmap();
        ByteArrayOutputStream bAOS =  new ByteArrayOutputStream();
        bitmAConv.compress(Bitmap.CompressFormat.JPEG, 100, bAOS);
        byte[] byteArray = bAOS.toByteArray();
        return byteArray;
    }
    */


}