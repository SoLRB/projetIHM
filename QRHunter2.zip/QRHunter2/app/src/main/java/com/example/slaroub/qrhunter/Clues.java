package com.example.slaroub.qrhunter;

import java.io.Serializable;

/**
 * Created by Sophiane on 07/04/2018.
 */

public class Clues implements Serializable {
    int NUMETAPE_;
    String INDTEXTE_, INDPHOTO_, INDAUDIO_;

    public int getNUMETAPE_() {
        return NUMETAPE_;
    }

    public String getINDAUDIO_() {
        return INDAUDIO_;
    }

    public String getINDPHOTO_() {
        return INDPHOTO_;
    }

    public String getINDTEXTE_() {
        return INDTEXTE_;
    }

    public void setINDAUDIO_(String INDAUDIO_) {
        this.INDAUDIO_ = INDAUDIO_;
    }

    public void setINDPHOTO_(String INDPHOTO_) {
        this.INDPHOTO_ = INDPHOTO_;
    }

    public void setINDTEXTE_(String INDTEXTE_) {
        this.INDTEXTE_ = INDTEXTE_;
    }

    public void setNUMETAPE_(int NUMETAPE_) {
        this.NUMETAPE_ = NUMETAPE_;
    }
}
