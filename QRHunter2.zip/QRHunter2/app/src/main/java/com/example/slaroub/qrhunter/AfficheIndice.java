package com.example.slaroub.qrhunter;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;

public class AfficheIndice extends AppCompatActivity {
    ImageView myImage;
    ArrayList<Clues> indicesRecup;
    int numeroEtape = 1;
    String nom;
    EditText indiceTexte;
    Typeface custFont;
    ImageView indiceAudio;
    ImageView btSon;
    MediaPlayer mediaPlayer;
    TextView tvI, tvA, tvT;
    String cheminPhoto, cheminAudio, cheminTexte;
   // ImageView boutonBack;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_affiche_indice);
        indicesRecup = new ArrayList<>();
        tvA = findViewById(R.id.tvAudio);
        tvI = findViewById(R.id.tvIndiceImage);
        tvT = findViewById(R.id.tvIndTexte);
        indiceTexte = findViewById(R.id.etIndiceTexte);
        btSon = findViewById(R.id.boutonSon);
        //indiceAudio = findViewById(R.id.ivAudio);
        indiceTexte.setClickable(false);
        mediaPlayer = new MediaPlayer();
        myImage = (ImageView) findViewById(R.id.indiceImage);
       // boutonBack = findViewById(R.id.boutonRetour);


        custFont = Typeface.createFromAsset(getAssets(), "fonts/Funny & Cute.ttf");

        tvT.setTextColor(Color.WHITE);
        tvT.setTypeface(custFont);
        tvT.setText("Indice textuel.");

        tvI.setTextColor(Color.WHITE);
        tvI.setTypeface(custFont);
        tvI.setText("Indice visuel.");

        tvA.setTextColor(Color.WHITE);
        tvA.setTypeface(custFont);
        tvA.setText("Indice auditif.");

        /*boutonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(AfficheIndice.this, RejoindreChasse.class);
                startActivity(intent);
            }
        });*/


        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            String pat = extras.getString("path");
            nom = extras.getString("nomChasse");
            if (extras.get("lesIndices") != null) {
                indicesRecup = (ArrayList<Clues>) extras.get("lesIndices");
                cheminPhoto = indicesRecup.get(0).getINDPHOTO_();
                cheminAudio = indicesRecup.get(0).getINDAUDIO_();
                cheminTexte = indicesRecup.get(0).getINDTEXTE_();
                if (!(cheminAudio == "")) {
                    tvA.setVisibility(View.VISIBLE);
                    btSon.setVisibility(View.VISIBLE);
                    mediaPlayer = new MediaPlayer();
                    try {
                        mediaPlayer.setDataSource(cheminAudio);
                        mediaPlayer.prepare();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }


                    btSon.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View view) {
                            mediaPlayer.start();
                        }
                    });

                }

                if (!(cheminPhoto.equalsIgnoreCase("."))) {

                    File imgFile = new File("" + indicesRecup.get(0).getINDPHOTO_());
                    if (imgFile.exists()) {
                        Bitmap myBitmap = BitmapFactory.decodeFile(imgFile.getAbsolutePath());
                        myImage = (ImageView) findViewById(R.id.indiceImage);
                        myImage.setImageBitmap(myBitmap);
                        myImage.setVisibility(View.VISIBLE);
                        tvI.setVisibility(View.VISIBLE);
                    }
                }
                if (cheminTexte != null) {
                    indiceTexte.setText(indicesRecup.get(0).getINDTEXTE_());
                    indiceTexte.setTextColor(Color.WHITE);
                    indiceTexte.setTypeface(custFont);
                    indiceTexte.setVisibility(View.VISIBLE);
                    tvT.setVisibility(View.VISIBLE);
                }


            }

        }

    }


}
