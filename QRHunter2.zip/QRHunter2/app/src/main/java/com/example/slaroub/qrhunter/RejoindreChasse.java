package com.example.slaroub.qrhunter;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;

import java.io.File;
import java.util.ArrayList;

public class RejoindreChasse extends AppCompatActivity {
    ImageView btReader,btReader2,btReader3,btReader4,btReader5,btReader6,btReader7,btReader8,btReader9,btReader10;
    String nomChasse;
    DBAdapter db;
    Typeface custFont;
    ArrayList<Clues> indicesRecup;
    int etapeMax;
    int numeroEtape = 1;

    LinearLayout lin1, lin2, lin3, lin4, lin5, lin6, lin7, lin8, lin9, lin10;

    TextView tvET1,tvET2,tvET3,tvET4,tvET5,tvET6,tvET7,tvET8, tvET9, tvET10;
    ImageView ivET1,ivET2,ivET3,ivET4,ivET5,ivET6,ivET7,ivET8, ivET9, ivET10;

    ImageView tivET1,tivET2,tivET3,tivET4,tivET5,tivET6,tivET7,tivET8, tivET9, tivET10;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rejoindre_chasse);
        custFont = Typeface.createFromAsset(getAssets(), "fonts/Funny & Cute.ttf");

        tvET1 = findViewById(R.id.tvEtape1);
        tvET1.setTextColor(Color.WHITE);
        tvET1.setTypeface(custFont);
        tvET1.setText("Etape 1");
        tvET1.setTextSize(26);
        tvET1.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);

        tvET2 = findViewById(R.id.tvEtape2);
        tvET2.setTextColor(Color.WHITE);
        tvET2.setTypeface(custFont);
        tvET2.setText("Etape 2");
        tvET2.setTextSize(26);
        tvET2.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);

        lin2 = findViewById(R.id.lL2);

        tvET3 = findViewById(R.id.tvEtape3);
        tvET3.setTextColor(Color.WHITE);
        tvET3.setTypeface(custFont);
        tvET3.setText("Etape 3");
        tvET3.setTextSize(26);
        tvET3.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);

        lin3 = findViewById(R.id.lL3);

        tvET4 = findViewById(R.id.tvEtape4);
        tvET4.setTextColor(Color.WHITE);
        tvET4.setTypeface(custFont);
        tvET4.setText("Etape 4");
        tvET4.setTextSize(26);
        tvET4.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);

        lin4 = findViewById(R.id.lL4);

        tvET5 = findViewById(R.id.tvEtape5);
        tvET5.setTextColor(Color.WHITE);
        tvET5.setTypeface(custFont);
        tvET5.setText("Etape 5");
        tvET5.setTextSize(26);
        tvET5.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);

        lin5 = findViewById(R.id.lL5);

        tvET6 = findViewById(R.id.tvEtape6);
        tvET6.setTextColor(Color.WHITE);
        tvET6.setTypeface(custFont);
        tvET6.setText("Etape 6");
        tvET6.setTextSize(26);
        tvET6.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);

        lin6 = findViewById(R.id.lL6);

        tvET7 = findViewById(R.id.tvEtape7);
        tvET7.setTextColor(Color.WHITE);
        tvET7.setTypeface(custFont);
        tvET7.setText("Etape 7");
        tvET7.setTextSize(26);
        tvET7.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);

        lin7 = findViewById(R.id.lL7);

        tvET8 = findViewById(R.id.tvEtape8);
        tvET8.setTextColor(Color.WHITE);
        tvET8.setTypeface(custFont);
        tvET8.setText("Etape 8");
        tvET8.setTextSize(26);
        tvET8.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);

        lin8 = findViewById(R.id.lL8);

        tvET9 = findViewById(R.id.tvEtape9);
        tvET9.setTextColor(Color.WHITE);
        tvET9.setTypeface(custFont);
        tvET9.setText("Etape 9");
        tvET9.setTextSize(26);
        tvET9.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);

        lin9 = findViewById(R.id.lL9);




        ivET1 = findViewById(R.id.nottck1);
        tivET1 = findViewById(R.id.tck1);

        ivET2 = findViewById(R.id.nottck2);
        tivET2 = findViewById(R.id.tck2);

        ivET3 = findViewById(R.id.nottck3);
        tivET3 = findViewById(R.id.tck3);

        ivET4 = findViewById(R.id.nottck4);
        tivET4 = findViewById(R.id.tck4);

        ivET5 = findViewById(R.id.nottck5);
        tivET5 = findViewById(R.id.tck5);

        ivET6 = findViewById(R.id.nottck6);
        tivET6 = findViewById(R.id.tck6);

        ivET7 = findViewById(R.id.nottck7);
        tivET7 = findViewById(R.id.tck7);

        ivET8 = findViewById(R.id.nottck8);
        tivET8 = findViewById(R.id.tck8);

        ivET9 = findViewById(R.id.nottck9);
        tivET9 = findViewById(R.id.tck9);




        db = new DBAdapter(this,"",null,1);
        etapeMax = db.renvoieMaxEtape(nomChasse);

        if(getIntent().getExtras()!=null) {
            Bundle p = getIntent().getExtras();
            nomChasse = p.getString("nomChasse");
        }


        btReader = (ImageView) findViewById(R.id.btQRReader);
        btReader2 = (ImageView) findViewById(R.id.btQRReader2);
        btReader3 = (ImageView) findViewById(R.id.btQRReader3);
        btReader4 = (ImageView) findViewById(R.id.btQRReader4);
        btReader5 = (ImageView) findViewById(R.id.btQRReader5);
        btReader6 = (ImageView) findViewById(R.id.btQRReader6);
        btReader7 = (ImageView) findViewById(R.id.btQRReader7);
        btReader8 = (ImageView) findViewById(R.id.btQRReader8);
        btReader9 = (ImageView) findViewById(R.id.btQRReader9);


        final Activity act = this;
        btReader.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                IntentIntegrator integrator = new IntentIntegrator(act);
                integrator.setDesiredBarcodeFormats(IntentIntegrator.QR_CODE_TYPES);
                integrator.setPrompt("Scan");
                integrator.setCameraId(0);
                integrator.setBeepEnabled(false);
                integrator.setBarcodeImageEnabled(false);
               // integrator.setOrientationLocked(false);

                integrator.initiateScan();
            }
        });

        btReader2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                IntentIntegrator integrator = new IntentIntegrator(act);
                integrator.setDesiredBarcodeFormats(IntentIntegrator.QR_CODE_TYPES);
                integrator.setPrompt("Scan");
                integrator.setCameraId(0);
                integrator.setBeepEnabled(false);
                integrator.setBarcodeImageEnabled(false);
                // integrator.setOrientationLocked(false);

                integrator.initiateScan();
            }
        });

        btReader3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                IntentIntegrator integrator = new IntentIntegrator(act);
                integrator.setDesiredBarcodeFormats(IntentIntegrator.QR_CODE_TYPES);
                integrator.setPrompt("Scan");
                integrator.setCameraId(0);
                integrator.setBeepEnabled(false);
                integrator.setBarcodeImageEnabled(false);
                // integrator.setOrientationLocked(false);

                integrator.initiateScan();
            }
        });

        btReader4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                IntentIntegrator integrator = new IntentIntegrator(act);
                integrator.setDesiredBarcodeFormats(IntentIntegrator.QR_CODE_TYPES);
                integrator.setPrompt("Scan");
                integrator.setCameraId(0);
                integrator.setBeepEnabled(false);
                integrator.setBarcodeImageEnabled(false);
                // integrator.setOrientationLocked(false);

                integrator.initiateScan();
            }
        });

        btReader5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                IntentIntegrator integrator = new IntentIntegrator(act);
                integrator.setDesiredBarcodeFormats(IntentIntegrator.QR_CODE_TYPES);
                integrator.setPrompt("Scan");
                integrator.setCameraId(0);
                integrator.setBeepEnabled(false);
                integrator.setBarcodeImageEnabled(false);
                // integrator.setOrientationLocked(false);

                integrator.initiateScan();
            }
        });

        btReader6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                IntentIntegrator integrator = new IntentIntegrator(act);
                integrator.setDesiredBarcodeFormats(IntentIntegrator.QR_CODE_TYPES);
                integrator.setPrompt("Scan");
                integrator.setCameraId(0);
                integrator.setBeepEnabled(false);
                integrator.setBarcodeImageEnabled(false);
                // integrator.setOrientationLocked(false);

                integrator.initiateScan();
            }
        });

        btReader7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                IntentIntegrator integrator = new IntentIntegrator(act);
                integrator.setDesiredBarcodeFormats(IntentIntegrator.QR_CODE_TYPES);
                integrator.setPrompt("Scan");
                integrator.setCameraId(0);
                integrator.setBeepEnabled(false);
                integrator.setBarcodeImageEnabled(false);
                // integrator.setOrientationLocked(false);

                integrator.initiateScan();
            }
        });

        btReader8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                IntentIntegrator integrator = new IntentIntegrator(act);
                integrator.setDesiredBarcodeFormats(IntentIntegrator.QR_CODE_TYPES);
                integrator.setPrompt("Scan");
                integrator.setCameraId(0);
                integrator.setBeepEnabled(false);
                integrator.setBarcodeImageEnabled(false);
                // integrator.setOrientationLocked(false);

                integrator.initiateScan();
            }
        });

        btReader9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                IntentIntegrator integrator = new IntentIntegrator(act);
                integrator.setDesiredBarcodeFormats(IntentIntegrator.QR_CODE_TYPES);
                integrator.setPrompt("Scan");
                integrator.setCameraId(0);
                integrator.setBeepEnabled(false);
                integrator.setBarcodeImageEnabled(false);
                // integrator.setOrientationLocked(false);

                integrator.initiateScan();
            }
        });


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);

        if(result != null){
            if(result.getContents()==null){
                Toast.makeText(this, "Vous avez arreté le scan", Toast.LENGTH_SHORT).show();
            }
            else{
                indicesRecup=new ArrayList<>();
                db.rempliIndices(indicesRecup, nomChasse, numeroEtape, result.getContents());
                if(indicesRecup.size()>0 && numeroEtape!=etapeMax){
                    if(numeroEtape==1 && numeroEtape!=etapeMax){
                        ivET1.setVisibility(View.INVISIBLE);
                        tivET1.setVisibility(View.VISIBLE);
                        lin2.setVisibility(View.VISIBLE);
                    }

                    if(numeroEtape==2 && numeroEtape!=etapeMax){
                        ivET2.setVisibility(View.INVISIBLE);
                        tivET2.setVisibility(View.VISIBLE);
                        lin3.setVisibility(View.VISIBLE);
                    }
                    if(numeroEtape==3 && numeroEtape!=etapeMax){
                        ivET3.setVisibility(View.INVISIBLE);
                        tivET3.setVisibility(View.VISIBLE);
                        lin4.setVisibility(View.VISIBLE);
                    }
                    if(numeroEtape==4 && numeroEtape!=etapeMax){
                        ivET4.setVisibility(View.INVISIBLE);
                        tivET4.setVisibility(View.VISIBLE);
                        lin5.setVisibility(View.VISIBLE);
                    }
                    if(numeroEtape==5 && numeroEtape!=etapeMax){
                        ivET5.setVisibility(View.INVISIBLE);
                        tivET5.setVisibility(View.VISIBLE);
                        lin6.setVisibility(View.VISIBLE);
                    }
                    if(numeroEtape==6 && numeroEtape!=etapeMax){
                        ivET6.setVisibility(View.INVISIBLE);
                        tivET6.setVisibility(View.VISIBLE);
                        lin7.setVisibility(View.VISIBLE);
                    }
                    if(numeroEtape==7 && numeroEtape!=etapeMax){
                        ivET7.setVisibility(View.INVISIBLE);
                        tivET7.setVisibility(View.VISIBLE);
                        lin8.setVisibility(View.VISIBLE);
                    }
                    if(numeroEtape==8 && numeroEtape!=etapeMax){
                        ivET8.setVisibility(View.INVISIBLE);
                        tivET8.setVisibility(View.VISIBLE);
                        lin9.setVisibility(View.VISIBLE);
                    }
                    if(numeroEtape==9 && numeroEtape!=etapeMax){
                        ivET9.setVisibility(View.INVISIBLE);
                        tivET9.setVisibility(View.VISIBLE);
                        lin10.setVisibility(View.VISIBLE);
                    }
                    if(numeroEtape==10 && numeroEtape!=etapeMax){
                        ivET10.setVisibility(View.INVISIBLE);
                        tivET10.setVisibility(View.VISIBLE);

                    }
                    AlertDialog.Builder dialog = new AlertDialog.Builder((RejoindreChasse.this));


                    dialog.setTitle("Bravo !");
                    dialog.setMessage("Vous avez complété l'étape " +numeroEtape+". Consultez les indices pour l'étape suivante !");



                    dialog.setPositiveButton("Voir les indices", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            numeroEtape++;
                            Intent intent = new Intent(RejoindreChasse.this, AfficheIndice.class);
                            intent.putExtra("lesIndices", indicesRecup);
                            startActivity(intent);
                            dialog.dismiss();
                        }
                    });
                    dialog.show();

                   // Toast.makeText(this, "Félicitations, vous passez a l'etape suivante !", Toast.LENGTH_SHORT).show();
                }else if(indicesRecup.size()>0 && numeroEtape==etapeMax){
                    AlertDialog.Builder dialog = new AlertDialog.Builder((RejoindreChasse.this));


                    dialog.setTitle("Félicitations !");
                    dialog.setMessage("Vous avez complété la chasse " +nomChasse+". Depechez vous de rejoindre le commanditaire !");



                    dialog.setPositiveButton("Terminer", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Intent intent = new Intent(RejoindreChasse.this, displayMenu.class);

                            startActivity(intent);
                            dialog.dismiss();
                        }
                    });
                    dialog.show();
                }

                else {
                    AlertDialog.Builder dialog = new AlertDialog.Builder((RejoindreChasse.this));


                    dialog.setTitle("Ah...");
                    dialog.setMessage("Cet indice ne correspond pas à l'étape courrante, essayez de revenir sur vos pas !");



                    dialog.setPositiveButton("Retour", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                            dialog.dismiss();
                        }
                    });
                    dialog.show();

                    //Toast.makeText(this, "Aucun indice ne correspond", Toast.LENGTH_SHORT).show();
                }
                /*
                Intent intent = new Intent(RejoindreChasse.this, AfficheIndice.class);
                intent.putExtra("path", result.getContents());
                intent.putExtra("nomChasse", nomChasse);*/

               // startActivity(intent);
               //  Toast.makeText(this, result.getContents(), Toast.LENGTH_SHORT).show();

            }
        }
        else{
            super.onActivityResult(requestCode, resultCode, data);
        }
    }
}
