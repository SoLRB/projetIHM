package com.example.slaroub.qrhunter;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import com.nbsp.materialfilepicker.MaterialFilePicker;
import com.nbsp.materialfilepicker.ui.FilePickerActivity;

import java.util.ArrayList;
import java.util.regex.Pattern;

public class CreerChasse extends AppCompatActivity {
    TextView tVPath, tVPath2, tVPath3;
    ArrayList<Clues> nosIndices;
    Clues clue;
    int numEtape =0;
    LinearLayout vuederoul;
    ScrollView sc;
    Typeface custFont;
    String cheminPhoto_, cheminAudio_, cheminTexte_;
    TextView tVEtape;
    TextView tVEtape1;
    TextView tVEtape2;
    TextView tVEtape3;
    TextView tVEtape4;
    TextView tVEtape5;
    TextView tVEtape6;
    TextView tVEtape7;
    TextView tVEtape8;
    TextView tVEtape9;
    TextView tVEtape10;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_creer_chasse);
        vuederoul = (LinearLayout) findViewById(R.id.vueDeroul);

        sc = (ScrollView) findViewById(R.id.sC);
        custFont = Typeface.createFromAsset(getAssets(),"fonts/Funny & Cute.ttf");


        TextView tVEtape = (TextView) findViewById(R.id.textView);
        TextView tVEtape2 = (TextView) findViewById(R.id.textView2);
        TextView tVEtape3 = (TextView) findViewById(R.id.textView3);
        TextView tVEtape4 = (TextView) findViewById(R.id.textView4);
        TextView tVEtape5 = (TextView) findViewById(R.id.textView5);
        TextView tVEtape6 = (TextView) findViewById(R.id.textView6);
        TextView tVEtape7 = (TextView) findViewById(R.id.textView7);
        TextView tVEtape8 = (TextView) findViewById(R.id.textView8);
        TextView tVEtape9 = (TextView) findViewById(R.id.textView9);
        TextView tVEtape10 = (TextView) findViewById(R.id.textView10);


        nosIndices = new ArrayList<>();

        if(getIntent().getExtras()!=null) {
            Bundle p = getIntent().getExtras();
            if((p.get("cheminTexte"))==""){
                cheminTexte_="";
            }else {
                cheminTexte_ = p.getString("cheminTexte");
            }
            if((p.getString("cheminPhoto"))=="."){
                cheminPhoto_ ="";
            }else {
                cheminPhoto_ = p.getString("cheminPhoto");
            }
            cheminAudio_ = p.getString("cheminAudio");

            // = "" si pas de son
            /*Toast.makeText(this, cheminPhoto_, Toast.LENGTH_SHORT).show();
               = "." si pas de photo
             */
            numEtape = p.getInt("numetape");

            if(p.get("liste")!=null){
                nosIndices = (ArrayList<Clues>) p.get("liste");
            }

            clue = new Clues();
            clue.setNUMETAPE_(numEtape);
            clue.setINDAUDIO_(cheminAudio_);
            clue.setINDPHOTO_(cheminPhoto_);
            clue.setINDTEXTE_(cheminTexte_);
            nosIndices.add(clue);




            if (numEtape == 1) {
                prepareTextView(tVEtape);
                tVEtape.setVisibility(View.VISIBLE);

                sc.fullScroll(ScrollView.FOCUS_DOWN);
            } else if (numEtape == 2) {
                prepareTextView(tVEtape2);
                tVEtape.setVisibility(View.VISIBLE);
                tVEtape2.setVisibility(View.VISIBLE);
                sc.fullScroll(ScrollView.FOCUS_DOWN);
            } else if (numEtape == 3) {
                prepareTextView(tVEtape3);
                tVEtape.setVisibility(View.VISIBLE);
                tVEtape2.setVisibility(View.VISIBLE);
                tVEtape3.setVisibility(View.VISIBLE);
                sc.fullScroll(ScrollView.FOCUS_DOWN);
            } else if (numEtape == 4) {
                tVEtape.setVisibility(View.VISIBLE);
                tVEtape2.setVisibility(View.VISIBLE);
                tVEtape3.setVisibility(View.VISIBLE);
                tVEtape4.setVisibility(View.VISIBLE);
                prepareTextView(tVEtape4);
                sc.fullScroll(ScrollView.FOCUS_DOWN);
            } else if (numEtape == 5) {
                tVEtape.setVisibility(View.VISIBLE);
                tVEtape2.setVisibility(View.VISIBLE);
                tVEtape3.setVisibility(View.VISIBLE);
                tVEtape4.setVisibility(View.VISIBLE);
                tVEtape5.setVisibility(View.VISIBLE);
                prepareTextView(tVEtape5);
                sc.fullScroll(ScrollView.FOCUS_DOWN);
            } else if (numEtape == 6) {
                tVEtape.setVisibility(View.VISIBLE);
                tVEtape2.setVisibility(View.VISIBLE);
                tVEtape3.setVisibility(View.VISIBLE);
                tVEtape4.setVisibility(View.VISIBLE);
                tVEtape5.setVisibility(View.VISIBLE);
                tVEtape6.setVisibility(View.VISIBLE);
                prepareTextView(tVEtape6);
                sc.fullScroll(ScrollView.FOCUS_DOWN);
            } else if (numEtape == 7) {
                tVEtape.setVisibility(View.VISIBLE);
                tVEtape2.setVisibility(View.VISIBLE);
                tVEtape3.setVisibility(View.VISIBLE);
                tVEtape4.setVisibility(View.VISIBLE);
                tVEtape5.setVisibility(View.VISIBLE);
                tVEtape6.setVisibility(View.VISIBLE);
                tVEtape7.setVisibility(View.VISIBLE);
                prepareTextView(tVEtape7);
                sc.fullScroll(ScrollView.FOCUS_DOWN);
            } else if (numEtape == 8) {
                tVEtape.setVisibility(View.VISIBLE);
                tVEtape2.setVisibility(View.VISIBLE);
                tVEtape3.setVisibility(View.VISIBLE);
                tVEtape4.setVisibility(View.VISIBLE);
                tVEtape5.setVisibility(View.VISIBLE);
                tVEtape6.setVisibility(View.VISIBLE);
                tVEtape7.setVisibility(View.VISIBLE);
                tVEtape8.setVisibility(View.VISIBLE);
                prepareTextView(tVEtape8);
                sc.fullScroll(ScrollView.FOCUS_DOWN);
            } else if (numEtape == 9) {
                tVEtape.setVisibility(View.VISIBLE);
                tVEtape2.setVisibility(View.VISIBLE);
                tVEtape3.setVisibility(View.VISIBLE);
                tVEtape4.setVisibility(View.VISIBLE);
                tVEtape5.setVisibility(View.VISIBLE);
                tVEtape6.setVisibility(View.VISIBLE);
                tVEtape7.setVisibility(View.VISIBLE);
                tVEtape8.setVisibility(View.VISIBLE);
                tVEtape9.setVisibility(View.VISIBLE);
                prepareTextView(tVEtape9);
                sc.fullScroll(ScrollView.FOCUS_DOWN);
            } else if (numEtape == 10) {
                tVEtape.setVisibility(View.VISIBLE);
                tVEtape2.setVisibility(View.VISIBLE);
                tVEtape3.setVisibility(View.VISIBLE);
                tVEtape4.setVisibility(View.VISIBLE);
                tVEtape5.setVisibility(View.VISIBLE);
                tVEtape6.setVisibility(View.VISIBLE);
                tVEtape7.setVisibility(View.VISIBLE);
                tVEtape8.setVisibility(View.VISIBLE);
                tVEtape9.setVisibility(View.VISIBLE);
                tVEtape10.setVisibility(View.VISIBLE);
                prepareTextView(tVEtape10);
                sc.fullScroll(ScrollView.FOCUS_DOWN);
            }


            prepareTextView(tVEtape);
            prepareTextView(tVEtape2);
            prepareTextView(tVEtape3);
            prepareTextView(tVEtape4);
            prepareTextView(tVEtape5);
            prepareTextView(tVEtape6);
            prepareTextView(tVEtape7);
            prepareTextView(tVEtape8);
            prepareTextView(tVEtape9);
            prepareTextView(tVEtape10);

            tVEtape.setText("Etape 1");
            tVEtape.setPadding(0,0,0,100);
            tVEtape2.setText("Etape 2");
            tVEtape2.setPadding(0,0,0,100);
            tVEtape3.setText("Etape 3");
            tVEtape3.setPadding(0,0,0,100);
            tVEtape4.setText("Etape 4");
            tVEtape4.setPadding(0,0,0,100);
            tVEtape5.setText("Etape 5");
            tVEtape5.setPadding(0,0,0,100);
            tVEtape6.setText("Etape 6");
            tVEtape6.setPadding(0,0,0,100);
            tVEtape7.setText("Etape 7");
            tVEtape7.setPadding(0,0,0,100);
            tVEtape8.setText("Etape 8");
            tVEtape8.setPadding(0,0,0,100);
            tVEtape9.setText("Etape 9");
            tVEtape9.setPadding(0,0,0,100);
            tVEtape10.setText("Etape 10");


            vuederoul.setDividerPadding(100);

            Toast.makeText(this, cheminAudio_, Toast.LENGTH_SHORT).show();
        }


        // = "" si pas de son
            /*Toast.makeText(this, cheminPhoto_, Toast.LENGTH_SHORT).show();
               = "." si pas de photo
             */



        ImageView ajouterIndice = (ImageView) findViewById(R.id.ajtIndice);
        ajouterIndice.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(CreerChasse.this, AjouterIndice.class);
                intent.putExtra("etape", numEtape);
                if(nosIndices!=null || nosIndices.size()>0){
                    intent.putExtra("liste", nosIndices);
                }
                startActivity(intent);
            }
        });

        ImageView validerChasse = (ImageView) findViewById(R.id.vdChasse);
        validerChasse.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(CreerChasse.this, ChoisirNom.class);
                intent.putExtra("list", nosIndices);
                startActivity(intent);
            }
        });


    }








    public void prepareTextView(TextView tv){
        //tv.setText("Etape "+numEtape);
        tv.setTextColor(Color.WHITE);
        tv.setTypeface(custFont);
        tv.setGravity(Gravity.CENTER);
        tv.setTextSize(20);

    }

}
