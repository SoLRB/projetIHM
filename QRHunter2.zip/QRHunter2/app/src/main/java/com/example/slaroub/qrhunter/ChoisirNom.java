package com.example.slaroub.qrhunter;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInstaller;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Environment;
import android.support.annotation.RequiresApi;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;


import com.google.zxing.BarcodeFormat;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.qrcode.QRCodeWriter;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.Properties;
import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;


public class ChoisirNom extends AppCompatActivity {


    Typeface custFont;
    ArrayList<Clues> indicesRecup;
    ArrayList<String>aleaRecup;
    ArrayList<String>recupLiens;
    ImageView valider;
    DBAdapter db;
    EditText edNom, edAdresse;
    private static final String ALPHABET = "123456789abcdefghjkmnpqrstuvwxyz";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_choisir_nom);
        valider= (ImageView) findViewById(R.id.vdChasse);
        aleaRecup = new ArrayList();
        recupLiens = new ArrayList();
        db = new DBAdapter(this,"",null,1);

        if(getIntent().getExtras()!=null) {
            Bundle p = getIntent().getExtras();
            indicesRecup = (ArrayList<Clues>) p.get("list");
           // Toast.makeText(this, indicesRecup.get(1).getINDAUDIO_(), Toast.LENGTH_SHORT).show();
        }

        custFont = Typeface.createFromAsset(getAssets(),"fonts/Funny & Cute.ttf");

        edNom = (EditText) findViewById(R.id.etNom);
        edAdresse = (EditText) findViewById(R.id.etAdresse);
        edNom.setTypeface(custFont);
        edNom.setHintTextColor(Color.WHITE);
        edNom.setTextColor(Color.WHITE);
        edNom.setTextSize(25);
        edNom.setHint("Entrez un nom");
        edNom.setGravity(Gravity.CENTER);

        edAdresse.setTypeface(custFont);
        edAdresse.setHintTextColor(Color.WHITE);
        edAdresse.setTextColor(Color.WHITE);
        edAdresse.setTextSize(25);
        edAdresse.setHint("Entrez une adresse");
        edAdresse.setGravity(Gravity.CENTER);

        //String txt = random();
        //Toast.makeText(this, txt, Toast.LENGTH_SHORT).show();
        valider.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
            @Override
            public void onClick(View view) {
                if((indicesRecup!=null || indicesRecup.size()>0)&& (edNom.getText().toString()!="")){
                    SendMailTask sendMail =new SendMailTask();
                    sendMail.execute();
                   // db.dropTable();
                    String alea = random(16);
                    int numRef =1;
                    for(int i=0; i<indicesRecup.size();i++) {
                        if(indicesRecup.get(i).getNUMETAPE_()!=numRef){
                            alea=random(16);
                            numRef=indicesRecup.get(i).getNUMETAPE_();
                        }
                        if(!(aleaRecup.contains(alea))){
                            aleaRecup.add(alea);
                        }
                        db.insertIndices(edNom.getText().toString(), alea, indicesRecup.get(i).getNUMETAPE_(), indicesRecup.get(i).getINDTEXTE_(), indicesRecup.get(i).getINDPHOTO_(), indicesRecup.get(i).getINDAUDIO_());

                    }


                    Intent intent = new Intent(ChoisirNom.this, displayMenu.class);
                    startActivity(intent);
                }


            }
        });



    }

    /*
    public static String random() {
        Random generator = new Random();
        StringBuilder randomStringBuilder = new StringBuilder();
        int randomLength = generator.nextInt(MAX_LENGTH);
        char tempChar;
        for (int i = 0; i < randomLength; i++){
            tempChar = (char) (generator.nextInt(96) + 32);
            randomStringBuilder.append(tempChar);
        }
        return randomStringBuilder.toString();
    }*/



    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public static String random(int length) {
        Random random = ThreadLocalRandom.current();
        int alphabetLength = ALPHABET.length();
        char[] chars = new char[length];
        for (int i = 0; i < length; i++)
            chars[i] = ALPHABET.charAt(random.nextInt(alphabetLength));
        return String.valueOf(chars);
    }


    public boolean isOnline() {
        ConnectivityManager cm =
                (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        if (netInfo != null && netInfo.isConnectedOrConnecting()) {
            return true;
        }
        return false;
    }

    public class SendMailTask extends AsyncTask<Void, Integer, Void>
    {


        @Override
        protected Void doInBackground(Void... voids) {
            for(int x = 0; x < aleaRecup.size(); x++){
                Bitmap qrasauver = encodeToQrCode(aleaRecup.get(x));
                recupLiens.add(SaveImage(qrasauver));
            }



            if(isOnline()) {
                Properties props = new Properties();
                props.put("mail.smtp.auth", "true");
                props.put("mail.smtp.starttls.enable", "true");
                props.put("mail.smtp.host", "smtp.gmail.com");
                props.put("mail.smtp.port", "587");

                final String username = "projetqrhunter@gmail.com";
                final String password = "projetqrhunter2018";

                Session session = Session.getInstance(props,
                        new javax.mail.Authenticator() {
                            protected PasswordAuthentication getPasswordAuthentication() {
                                return new PasswordAuthentication(username, password);
                            }
                        });

                try {
                    MimeMessage message = new MimeMessage(session);
                    message.setFrom(new InternetAddress("projetqrhunter@gmail.com"));
                        message.setRecipients(MimeMessage.RecipientType.TO,
                                InternetAddress.parse(edAdresse.getText().toString()));
                        message.setSubject("Recapitulatif de votre chasse");
                        message.setText("Bonjour ! C'est un test.");

                        MimeBodyPart messageBodyPart = new MimeBodyPart();
                        Multipart multipart = new MimeMultipart();
                        for(int a=0; a < recupLiens.size();a++){
                            messageBodyPart = new MimeBodyPart();
                            String file = recupLiens.get(a).toString();
                            String fileName = "Etape "+(a+1);
                            DataSource source = new FileDataSource(file);
                            messageBodyPart.setDataHandler(new DataHandler(source));
                            messageBodyPart.setFileName(fileName);
                            multipart.addBodyPart(messageBodyPart);
                            message.setContent(multipart);
                        }
                        /*
                Multipart multipart = new MimeMultipart();

                messageBodyPart = new MimeBodyPart();
                String file = "path of file to be attached";
                String fileName = "attachmentName";
                DataSource source = new FileDataSource(file);
                messageBodyPart.setDataHandler(new DataHandler(source));
                messageBodyPart.setFileName(fileName);
                multipart.addBodyPart(messageBodyPart);

                message.setContent(multipart);*/

                        Transport.send(message);

                        System.out.println("Done");
                    }catch (MessagingException e) {
                    throw new RuntimeException(e);
                }
            }


            return null;

        }
    }

    public static Bitmap encodeToQrCode(String text){
        QRCodeWriter writer = new QRCodeWriter();
        BitMatrix matrix = null;
        try {
            matrix = writer.encode(text, BarcodeFormat.QR_CODE, 512, 512);
        } catch (WriterException ex) {
            ex.printStackTrace();
        }
        int width = matrix.getWidth();
        int height = matrix.getHeight();
        Bitmap bmp = Bitmap.createBitmap(width, height, Bitmap.Config.RGB_565);
        for (int x = 0; x < width; x++){
            for (int y = 0; y < height; y++){
                bmp.setPixel(x, y, matrix.get(x,y) ? Color.BLACK : Color.WHITE);
            }
        }
        return bmp;
    }

    private String SaveImage(Bitmap finalBitmap) {

        String root = Environment.getExternalStorageDirectory().toString();
        File myDir = new File(root + "/saved_qrcodes");
        myDir.mkdirs();
        Random generator = new Random();
        int n = 10000;
        n = generator.nextInt(n);
        String fname = "Image-"+ n +".jpg";
        File file = new File (myDir, fname);
        if (file.exists ()) file.delete ();
        try {
            FileOutputStream out = new FileOutputStream(file);
            finalBitmap.compress(Bitmap.CompressFormat.JPEG, 90, out);
            out.flush();
            out.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
        String lien = myDir.getAbsolutePath()+"/"+fname;
        return lien;
    }



}
