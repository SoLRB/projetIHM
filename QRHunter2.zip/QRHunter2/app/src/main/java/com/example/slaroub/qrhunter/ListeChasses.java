package com.example.slaroub.qrhunter;

import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

public class ListeChasses extends AppCompatActivity {
    Typeface custFont;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_liste_chasses);
        custFont = Typeface.createFromAsset(getAssets(), "fonts/Funny & Cute.ttf");
        final DBAdapter db = new DBAdapter(this, "", null, 1);


        final ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(ListeChasses.this, android.R.layout.simple_selectable_list_item) {
            @Override
            public View getView(int position, View convertView, ViewGroup parent) {

                View v = super.getView(position, convertView, parent);
                ((TextView) v).setTextColor(Color.WHITE);
                ((TextView) v).setTypeface(custFont);
                ((TextView) v).setBackgroundColor(Color.RED);
                return v;
            }

            @Override
            public View getDropDownView(int position, View convertView,
                                        ViewGroup parent) {
                // TODO Auto-generated method stub
                View v = super.getDropDownView(position, convertView, parent);
                ((TextView) v).setTextColor(Color.WHITE);
                ((TextView) v).setTypeface(custFont);
                ((TextView) v).setBackgroundColor(Color.RED);
                return v;
            }
        };

        final ListView listView = (ListView) findViewById(R.id.listeDeChasses);
        db.list_all_chasses(arrayAdapter);
        listView.setAdapter(arrayAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> myAdapter, View myView, int myItemInt, long mylng) {
                final String selectedFromList = (String) (listView.getItemAtPosition(myItemInt));
                AlertDialog.Builder dialog = new AlertDialog.Builder((ListeChasses.this));


                dialog.setTitle("Chasse selectionee");
                dialog.setMessage("Voulez vous lancer la chasse "+selectedFromList+ " ?");



                dialog.setPositiveButton("Confirmer", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Intent intent = new Intent(ListeChasses.this, RejoindreChasse.class);
                        intent.putExtra("nomChasse", selectedFromList);
                        startActivity(intent);
                        dialog.dismiss();
                    }
                });

                dialog.setNegativeButton("Annuler", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }
                });
                dialog.show();
            }
});
}
}
