package com.example.slaroub.qrhunter;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class displayMenu extends AppCompatActivity {
    Typeface custFont;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_menu);
        ImageView btDebuter = (ImageView) findViewById(R.id.btDebuter);
        ImageView btRejoindre = (ImageView) findViewById(R.id.btRejoindre);
        custFont = Typeface.createFromAsset(getAssets(),"fonts/Cake Nom.ttf");



        btDebuter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(displayMenu.this, CreerChasse.class);
                startActivity(intent);
            }
        });


        btRejoindre.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Intent intent = new Intent(displayMenu.this, RejoindreChasse.class);
                Intent intent = new Intent(displayMenu.this, ListeChasses.class);
                startActivity(intent);
            }
        });
    }

    public void initialiseTexte(TextView t){
        t.setGravity(Gravity.CENTER);
        t.setTextColor(Color.BLACK);
        t.setTypeface(custFont);
        t.setTextSize(30);
    }
}
