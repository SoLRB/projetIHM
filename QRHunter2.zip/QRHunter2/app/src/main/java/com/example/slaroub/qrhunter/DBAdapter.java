package com.example.slaroub.qrhunter;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.ArrayAdapter;

import java.util.ArrayList;

/**
 * Created by Sophiane on 01/04/2018.
 */

public class DBAdapter extends SQLiteOpenHelper
{
    public static final String KEY_NOMCHASSE = "nomchasse";
    public static final String KEY_QRID = "qrid";
    public static final String KEY_NUMETAPE = "numetape";
    public static final String KEY_INDTEXTE = "indtexte";
    public static final String KEY_INDAUDIO = "indaudio";
    public static final String KEY_INDPHOTO = "indphoto";

    private static final String TAG = "DBAdapter";

    private static final String DATABASE_NAME = "dbindices";
    private static final String DATABASE_TABLE = "indices";
    private static final int DATABASE_VERSION = 1;




    private SQLiteDatabase db;

    public DBAdapter(Context context, String name, SQLiteDatabase.CursorFactory factory, int version) {
        super(context, "DBINDICES.db", factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
      //  sqLiteDatabase.execSQL("CREATE TABLE INDICES(QRID INTEGER PRIMARY KEY, IDC INTEGER, NUMETAPE INTEGER NOT NULL, INDTEXTE VARCHAR(100), INDPHOTO BLOB NOT NULL);");
        sqLiteDatabase.execSQL("CREATE TABLE INDICES(NOMCHASSE VARCHAR(30), QRID VARCHAR(30) NOT NULL, NUMETAPE INTEGER NOT NULL, INDTEXTE VARCHAR(100), INDPHOTO VARCHAR(50), INDAUDIO VARCHAR(50));");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS INDICES;");
        onCreate(sqLiteDatabase);
    }

    public void dropTable(){
        this.getWritableDatabase().delete("INDICES","",null);
    }

    public void insertIndices(String nom, String qrid, int numetape, String indtexte, String image, String audio)
    {
        ContentValues initialValues = new ContentValues();
        initialValues.put(KEY_NOMCHASSE, nom);
        initialValues.put(KEY_QRID, qrid);
        initialValues.put(KEY_NUMETAPE, numetape);
        initialValues.put(KEY_INDTEXTE, indtexte);
        initialValues.put(KEY_INDPHOTO, image);
        initialValues.put(KEY_INDAUDIO, audio);
        this.getWritableDatabase().insertOrThrow("INDICES","",initialValues);
    }


    public Cursor getData(String sql){
        SQLiteDatabase database = getReadableDatabase();
        return database.rawQuery(sql, null);
    }




    public String renvoiePath(){
        String renvoie="";
        Cursor crs = this.getReadableDatabase().rawQuery("SELECT INDPHOTO FROM INDICES WHERE IDC =155;",null);
        while (crs.moveToNext()){
            renvoie = crs.getString(crs.getColumnIndex("INDPHOTO"));
        }
        return renvoie;
    }

    public void list_all_chasses(ArrayAdapter<String> aDAP) {

        Cursor crs = this.getReadableDatabase().rawQuery("SELECT DISTINCT NOMCHASSE FROM INDICES", null);
        // textView.setText("");
        while (crs.moveToNext()) {
            aDAP.add(crs.getString(0));


        }
    }

    public void rempliIndices(ArrayList<Clues> listeIndices, String nom, int numEtape, String chaine){
         Cursor crs = this.getReadableDatabase().rawQuery("SELECT * FROM INDICES WHERE NOMCHASSE ='"+nom+"' AND NUMETAPE="+numEtape+" AND QRID='"+chaine+"';", null);
        Clues clue = new Clues();
        while (crs.moveToNext()){
            clue.setINDTEXTE_(crs.getString(3));
            clue.setINDPHOTO_(crs.getString(4));
            clue.setINDAUDIO_(crs.getString(5));
            listeIndices.add(clue);


        }
    }

    public int renvoieMaxEtape(String nomChasse){

        String selectQuery = "SELECT MAX(NUMETAPE) AS ID FROM INDICES";
        SQLiteDatabase database = this.getWritableDatabase();
        Cursor cursor = database.rawQuery(selectQuery, null);

        cursor.moveToFirst();

        int etape = cursor.getInt(cursor.getColumnIndex("ID"));

        return etape;



    }


    }


